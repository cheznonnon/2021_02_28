// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_autofocus( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_win_txtbox_metrics_canvas( p );


	// [Needed] : set zero for x : when call many times

	p->scroll_pxl_tabbed_x = 0;//p->select_cch_x - ( p->page_pxl_tabbed_sx / 2 );
	p->scroll_cch_tabbed_y = p->select_cch_y - ( p->page_cch_tabbed_sy / 2 );
//n_posix_debug_literal( " %d : %d : %d ", p->scroll_cch_tabbed_y, p->select_cch_y, p->page_cch_tabbed_sy );


	s32 sel_x  = p->select_cch_x;
	s32 sel_y  = p->select_cch_y;
	s32 sel_sx = p->select_cch_sx;

	s32 txt_fx = 0; n_win_txtbox_tabbedmetrics( p, sel_y, -1,sel_x,-1, NULL,NULL,&txt_fx );
	s32 txt_tx = txt_fx + sel_sx;
	s32 scr_fx = p->scroll_pxl_tabbed_x / p->font_pxl_sx;
	s32 scr_tx = scr_fx + ( p->page_pxl_tabbed_sx / p->font_pxl_sx );

	if (
		( txt_fx < scr_fx )
		||
		( txt_tx > scr_tx )
	)
	{
		p->scroll_pxl_tabbed_x = ( txt_tx * p->font_pxl_sx ) - ( p->page_pxl_tabbed_sx / 2 );
	}


	// [Needed] : clamp when resized

	n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_cch_tabbed_y );


	// [!] : some functions rewrite position for calling through WM_COMMAND

	p->hscr.unit_pos = 0;
	p->vscr.unit_pos = 0;

	extern void n_win_txtbox_draw_scrollbars( n_win_txtbox *p, bool mask );
	n_win_txtbox_draw_scrollbars( p, false );
//n_posix_debug_literal( " %f ", p->vscr.unit_pos );


	// [Needed] : Win9x : reason is unknown

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_refresh( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_refresh( &p->vscr );
	}


	return;
}

void
n_win_txtbox_autofocus_smart( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if (
		(
			( p->scroll_cch_tabbed_y >   p->select_cch_y                      )
			&&
			( p->scroll_cch_tabbed_y > ( p->select_cch_y + p->select_cch_sy ) )
		)
		||
		( ( p->scroll_cch_tabbed_y + p->page_cch_tabbed_sy ) < p->select_cch_y )
	)
	{
		n_win_txtbox_autofocus( p );
	}


	return;
}

#define n_win_txtbox_str2index_literal( p, s, b ) n_win_txtbox_str2index( p, n_posix_literal( s ), b )

s32
n_win_txtbox_str2index( n_win_txtbox *p, const n_posix_char *str, bool autoselect )
{

	// [!] : be sure to check a returned value


	if ( p == NULL ) { return N_WIN_TXTBOX_NOT_SELECTED; }


	size_t i = 0;
	while( 1 )
	{

		if ( n_string_is_same( str, n_txt_get( &p->txt, i ) ) ) { break; }

		i++;
		if ( i >= p->txt.sy ) { return N_WIN_TXTBOX_NOT_SELECTED; }
	}


	if ( autoselect )
	{
		n_win_txtbox_line_select( p, i );
		n_win_txtbox_autofocus( p );
		n_win_txtbox_refresh( p );
	}


	return i;
}


