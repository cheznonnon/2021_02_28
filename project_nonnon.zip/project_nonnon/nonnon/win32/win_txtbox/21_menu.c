// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




bool
n_win_txtbox_menu_emptyline_cut( n_win_txtbox *p )
{

	bool ret = false;


	if ( p == NULL ) { return ret; }


	if ( p->empty_line_selection != N_WIN_TXTBOX_NOT_SELECTED )
	{

		n_win_txtbox_refresh_optimized_init( p );


		n_win_txtbox_edit_undo( p, false );

		n_win_txtbox_line_del( p, p->empty_line_selection );

		n_clipboard_text_set( p->hwnd, N_STRING_CRLF );

		p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


		n_win_txtbox_refresh_optimized_exit( p, true );


		ret = true;

	}


	return ret;
}

void
n_win_txtbox_menu_undo( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	// [!] : don't use optimized_init()/exit()
	//
	//	heap curruption will occur when string size will shorten


	//n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_undo( p, true );
	n_win_txtbox_autofocus_smart( p );

	n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );


	//n_win_txtbox_refresh_optimized_exit( p, true );


	n_win_txtbox_refresh( p );


	return;
}

void
n_win_txtbox_menu_delete( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( n_win_txtbox_menu_emptyline_cut( p ) ) { return; }


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_undo( p, false );
	n_win_txtbox_autofocus_smart( p );

	n_win_txtbox_edit_del( p );

	n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_cut( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( n_win_txtbox_menu_emptyline_cut( p ) ) { return; }


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_undo( p, false );
	n_win_txtbox_autofocus_smart( p );

	n_win_txtbox_edit_cut( p );

	if ( ( p->prv_sel_sy > 1 )&&( p->select_cch_y < p->scroll_cch_tabbed_y ) )
	{
		n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->select_cch_y );
	}

	n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_copy( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	//n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_autofocus_smart( p );

	n_win_txtbox_edit_copy( p );


	//n_win_txtbox_refresh_optimized_exit( p, true );

	n_win_txtbox_refresh( p );


	return;
}

void
n_win_txtbox_menu_paste( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	p->empty_line_selection = N_WIN_TXTBOX_NOT_SELECTED;


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_edit_undo( p, false );
	n_win_txtbox_autofocus_smart( p );

	bool ret = n_win_txtbox_edit_paste( p );

	if ( ret )
	{
		n_win_message_send( GetParent( p->hwnd ), WM_COMMAND, WM_KEYDOWN, p->hwnd );
	}


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_selectall( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	n_win_txtbox_refresh_optimized_init( p );


	n_win_txtbox_select( p, 0, 0, N_WIN_TXTBOX_ALL, N_WIN_TXTBOX_ALL );


	n_win_txtbox_refresh_optimized_exit( p, true );


	return;
}

void
n_win_txtbox_menu_insert( n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( n_win_is_input( VK_SHIFT ) )
	{
		n_win_txtbox_menu_paste( p );
	}


	return;
}

#define N_WIN_TXTBOX_PROC_MENU_UNDO      0
#define N_WIN_TXTBOX_PROC_MENU_LINE1     1
#define N_WIN_TXTBOX_PROC_MENU_CUT       2
#define N_WIN_TXTBOX_PROC_MENU_COPY      3
#define N_WIN_TXTBOX_PROC_MENU_PASTE     4
#define N_WIN_TXTBOX_PROC_MENU_DELETE    5
#define N_WIN_TXTBOX_PROC_MENU_LINE2     6
#define N_WIN_TXTBOX_PROC_MENU_SELECTALL 7

void
n_win_txtbox_proc_menu_editbox_init( n_win_txtbox *p )
{

	n_win_simplemenu_set( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_UNDO     , NULL, n_posix_literal( "[ ]Undo"       ), NULL );
	n_win_simplemenu_set( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_LINE1    , NULL, n_posix_literal( "[-]"           ), NULL );
	n_win_simplemenu_set( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_CUT      , NULL, n_posix_literal( "[ ]Cut"        ), NULL );
	n_win_simplemenu_set( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_COPY     , NULL, n_posix_literal( "[ ]Copy"       ), NULL );
	n_win_simplemenu_set( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_PASTE    , NULL, n_posix_literal( "[ ]Paste"      ), NULL );
	n_win_simplemenu_set( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_DELETE   , NULL, n_posix_literal( "[ ]Delete"     ), NULL );
	n_win_simplemenu_set( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_LINE2    , NULL, n_posix_literal( "[-]"           ), NULL );
	n_win_simplemenu_set( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_SELECTALL, NULL, n_posix_literal( "[ ]Select All" ), NULL );


	return;
}

void
n_win_txtbox_proc_menu_editbox( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( msg != WM_COMMAND ) { return; }

	if ( (HWND) lparam != p->menu_editbox.hwnd ) { return; }


	if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
	{

		n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_UNDO     , ' ' );
		n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_CUT      , ' ' );
		n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_COPY     , ' ' );
		n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_PASTE    , ' ' );
		n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_DELETE   , ' ' );
		n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_SELECTALL, ' ' );

		if ( n_txt_error( &p->txt_undo ) )
		{
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_UNDO, 'x' );
		}

		if ( ( p->select_cch_sx == N_WIN_TXTBOX_ALL )||( p->select_cch_sx != 0 ) )
		{
			//
		} else {
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_CUT   , 'x' );
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_COPY  , 'x' );
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_DELETE, 'x' );
		}

		if (
			( p->select_cch_sy == N_WIN_TXTBOX_ALL )
			||
			(
				( false == ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) )
				&&
				( p->select_cch_sy == p->txt.sy )
			)
			||
			(
				( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
				&&
				( p->select_cch_sx == n_posix_strlen( n_txt_get( &p->txt, 0 ) ) )
			)
		)
		{
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_SELECTALL, 'x' );
		}

		if ( p->txt.readonly )
		{
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_CUT   , 'x' );
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_COPY  , 'x' );
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_PASTE , 'x' );
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_DELETE, 'x' );
		} else {
			if ( p->undo_onoff == false )
			{
				n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_UNDO, 'x' );
			}

			if ( 1 >= n_clipboard_text_get( p->hwnd, NULL ) )
			{
				n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_PASTE, 'x' );
			}
		}

		if ( p->empty_line_selection != N_WIN_TXTBOX_NOT_SELECTED )
		{
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_CUT   , 'x' );
			n_win_simplemenu_tweak_literal( &p->menu_editbox, N_WIN_TXTBOX_PROC_MENU_DELETE, 'x' );
		}

	} else
	if ( wparam == N_WIN_TXTBOX_PROC_MENU_UNDO )
	{

		n_win_txtbox_menu_undo( p );

	} else
	if ( wparam == N_WIN_TXTBOX_PROC_MENU_CUT )
	{

		n_win_txtbox_menu_cut( p );

	} else
	if ( wparam == N_WIN_TXTBOX_PROC_MENU_COPY )
	{

		n_win_txtbox_menu_copy( p );

	} else
	if ( wparam == N_WIN_TXTBOX_PROC_MENU_PASTE )
	{

		n_win_txtbox_menu_paste( p );

	} else
	if ( wparam == N_WIN_TXTBOX_PROC_MENU_DELETE )
	{

		n_win_txtbox_menu_delete( p );

	} else
	if ( wparam == N_WIN_TXTBOX_PROC_MENU_SELECTALL )
	{
//n_win_txtbox_debug_count( p );

		n_win_txtbox_menu_selectall( p );

	}


	if ( wparam != N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
	{
		p->menu_onoff = false;
	}


	return;
}

#define N_WIN_TXTBOX_PROC_MENU_CARET 0

void
n_win_txtbox_proc_menu_linenum_init( n_win_txtbox *p )
{

	if ( false == ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) ) { return; }


	n_win_simplemenu_set( &p->menu_linenum, N_WIN_TXTBOX_PROC_MENU_CARET, NULL, n_posix_literal( "[ ]Caret" ), NULL );


	return;
}

void
n_win_txtbox_proc_menu_linenum( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_txtbox *p )
{

	if ( p == NULL ) { return; }


	if ( false == ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM ) ) { return; }


	if ( msg != WM_COMMAND ) { return; }

	if ( (HWND) lparam != p->menu_linenum.hwnd ) { return; }


	if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
	{

		//

	} else
	if ( wparam == N_WIN_TXTBOX_PROC_MENU_CARET )
	{

		n_win_txtbox_autofocus_smart( p );
		n_win_txtbox_refresh( p );

	}


	if ( wparam != N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
	{
		p->menu_onoff = false;
	}


	return;
}


