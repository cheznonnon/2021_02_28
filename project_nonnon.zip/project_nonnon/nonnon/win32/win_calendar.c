// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_CALENDAR
#define _H_NONNON_WIN32_WIN_CALENDAR




#include "./gdi/doublebuffer.c"
#include "./win.c"
#include "./win_scroll.c"




#define N_WIN_CALENDAR_INSTANCE n_posix_literal( "Nonnon.Win32.Calendar" )
#define N_WIN_CALENDAR_SUBCLASS n_posix_literal( "n_win_calendar_subclass()" )




typedef struct {

	HWND     hgui;
	WNDPROC pfunc;

	int     year, month, day;

} n_win_calendar;




// internal
HFONT
n_win_calendar_font( HWND hgui, LONG size, bool bold )
{

	// [Needed] : n_win_font_exit( hfont );


	LOGFONT lf = n_win_font_hwnd2logfont( hgui );

	lf.lfHeight = n_posix_min( lf.lfHeight, size );

	if ( bold ) { lf.lfWeight = FW_BOLD; }


	return n_win_font_logfont2hfont( &lf );
}

// internal
void
n_win_calendar_draw( HWND hgui, RECT rect, int year, int month, int day )
{

	const int divx = 7;
	const int divy = 1 + 6;

	const int  x = rect.left;
	const int  y = rect.top;
	const int sx = rect.right  - x;
	const int sy = rect.bottom - y;

	const int cellsx = sx / divx;
	const int cellsy = sy / divy;
	const int fontsy = cellsy;

	if ( cellsx <= 0 ) { return; }
	if ( cellsy <= 0 ) { return; }


	HDC hdc = n_gdi_doublebuffer_simple_init( hgui, sx,sy );


	// Clamp

	year  = n_posix_max( 1900, year );
	month = n_posix_minmax( 1, 12, month );


	// Colors

	COLORREF color_bg          = n_win_darkmode_systemcolor_ui( COLOR_WINDOW        );
	COLORREF color_text_normal = n_win_darkmode_systemcolor_ui( COLOR_WINDOWTEXT    );
	COLORREF color_back_hilite = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHT     );
	COLORREF color_text_hilite = n_win_darkmode_systemcolor_ui( COLOR_HIGHLIGHTTEXT );
	COLORREF color_text_grayed = n_win_darkmode_systemcolor_ui( COLOR_GRAYTEXT      );


	// Erase Background

	n_win_box( hgui, hdc, &rect, color_bg );

//n_gdi_doublebuffer_simple_exit(); return;


	// Header

	{

		RECT  r  = { x,y, x+sx, y+cellsy };
		HFONT hf = SelectObject( hdc, n_win_calendar_font( hgui, fontsy, true ) );
		int   dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );


		n_win_box( hgui, hdc, &r, color_back_hilite );

		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, "%4d %02d", year, month );

		SetBkColor  ( hdc, color_back_hilite );
		SetTextColor( hdc, color_text_hilite );

		DrawText( hdc, str,-1, &r, dt );


		n_win_font_exit( SelectObject( hdc, hf ) );

	}
//n_gdi_doublebuffer_simple_exit(); return;


	// Calendar

	{

		RECT     r;
		HFONT    hf = SelectObject( hdc, n_win_calendar_font( hgui, fontsy, false ) );
		int      dt = DT_CENTER | ( DT_SINGLELINE | DT_VCENTER );
		COLORREF fg, bg;

		n_posix_char str[ 10 ];

		int first = n_time_dayofweek( year, month );
		int last  = n_time_lastday  ( year, month );

		int today_year, today_month;
		n_time_today( &today_year, &today_month, NULL, NULL, NULL, NULL );

//n_win_hwndprintf_literal( GetParent( hgui ), "%d : %d", first, last );


		// [!] : don't do size-based approach : modulo handling is hard

		int  i = 0;
		s32 cx = 0;
		s32 cy = 0;
		s32 ox = ( ( sx % divx ) / 2 );
		s32 oy = ( ( sy % divy ) / 2 ) + cellsy;
		while( 1 )
		{

			r.left    = ox + x + ( cellsx * cx );
			r.top     = oy + y + ( cellsy * cy );
			r.right   = r.left + cellsx;
			r.bottom  = r.top  + cellsy;


			fg = color_text_normal;
			bg = color_bg;


			int today = ( i - first ) + 1;

			if ( ( today >= 1 )&&( today <= last ) ) 
			{

				if ( ( today_year == year )&&( today_month == month )&&( today == day ) )
				{

					n_win_rect_resize( &r, -2,-2 );

					n_win_box( hgui, hdc, &r, color_back_hilite );

					fg = color_text_hilite;
					bg = color_back_hilite;

				} else
				if ( today == day )
				{

					n_win_rect_resize( &r, -2,-2 );

					COLORREF tmp_bg = color_bg;
					COLORREF tmp_fg = color_back_hilite;

					tmp_bg = n_win_color_blend( tmp_bg, tmp_fg, 0.5 );

					n_win_box( hgui, hdc, &r, tmp_bg );

					fg = color_text_hilite;
					bg = tmp_bg;

				}

			} else
			if ( today > last )
			{

				today -= last;

				fg = color_text_grayed;

			} else
			if ( today <= 0 )
			{

				int y = year;
				int m = month - 1;

				if ( m == 0 ) { y--; m = 12; }

				today = n_time_lastday( y, m ) + today;

				fg = color_text_grayed;

			}


			n_posix_sprintf_literal( str, "%d", today );

			SetBkColor  ( hdc, bg );
			SetTextColor( hdc, fg );

			DrawText( hdc, str,-1, &r, dt );


			i++;

			cx++;
			if ( cx >= divx )
			{

				cx = 0;

				cy++;
				if ( cy >= divy ) { break; }
			}
		}

		n_win_font_exit( SelectObject( hdc, hf ) );

	}


	n_gdi_doublebuffer_simple_exit();


	return;
}

LRESULT CALLBACK
#ifdef _WIN64
n_win_calendar_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, UINT_PTR uIdSubclass, DWORD_PTR dwRefData )
#else  // #ifdef _WIN64
n_win_calendar_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
#endif // #ifdef _WIN64
{

#ifdef _WIN64

	n_win_calendar *p = (n_win_calendar*) dwRefData;
	if ( p == NULL ) { return 0; }

#else  // #ifdef _WIN64

	n_win_calendar *p = (n_win_calendar*) n_win_property_get( hwnd, N_WIN_CALENDAR_INSTANCE );
	if ( p == NULL ) { return 0; }

	const WNDPROC pfunc = (WNDPROC) n_win_property_get( hwnd, N_WIN_CALENDAR_SUBCLASS );
	if ( pfunc == NULL ) { return 0; }

#endif // #ifdef _WIN64


	switch( msg ) {


	case WM_LBUTTONDBLCLK :

		if ( n_win_is_hovered( p->hgui ) )
		{
			n_time_today( &p->year, &p->month, &p->day, NULL, NULL, NULL );
			n_win_refresh( p->hgui, false );
		}

	break;


	} // switch


#ifdef _WIN64
	return DefSubclassProc( hwnd, msg, wparam, lparam );
#else  // #ifdef _WIN64
	return CallWindowProc( pfunc, hwnd, msg, wparam, lparam );
#endif // #ifdef _WIN64
}

void
n_win_calendar_init( n_win_calendar *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return; }


	n_win_gui_literal( hwnd_parent, N_WIN_GUI_CANVAS_BUTTON, "", &p->hgui );


	n_win_stdfont_init( &p->hgui, 1 );


#ifdef _WIN64

	SetWindowSubclass( p->hgui, n_win_calendar_subclass, 0, (DWORD_PTR) p );

#else  // #ifdef _WIN64

	p->pfunc = n_win_gui_subclass_set( p->hgui, n_win_calendar_subclass );

	n_win_property_init( p->hgui, N_WIN_CALENDAR_INSTANCE, (int) p        );
	n_win_property_init( p->hgui, N_WIN_CALENDAR_SUBCLASS, (int) p->pfunc );

#endif // #ifdef _WIN64


	n_time_today( &p->year, &p->month, &p->day, NULL, NULL, NULL );


	return;
}

void
n_win_calendar_exit( n_win_calendar *p, HWND hwnd_parent )
{

	if ( p == NULL ) { return; }


#ifdef _WIN64

	RemoveWindowSubclass( p->hgui, n_win_calendar_subclass, 0 );

#else  // #ifdef _WIN64

	n_win_gui_subclass_set( p->hgui, p->pfunc );

	n_win_property_exit( p->hgui, N_WIN_CALENDAR_INSTANCE );
	n_win_property_exit( p->hgui, N_WIN_CALENDAR_SUBCLASS );

#endif // #ifdef _WIN64


	n_win_stdfont_exit( &p->hgui, 1 );


	DestroyWindow( p->hgui );


	return;
}

void
n_win_calendar_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_calendar *p )
{

	switch( msg ) {


	case WM_TIMECHANGE :

		n_time_today( &p->year, &p->month, &p->day, NULL, NULL, NULL );
		n_win_refresh( p->hgui, false );

	break;


	case WM_SIZE :
	{

		if ( false == IsWindow( p->hgui ) ) { break; }

		n_win_refresh( p->hgui, false );

	}
	break;


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( p->hgui != di->hwndItem ) { break; }

		n_win_calendar_draw( p->hgui, di->rcItem, p->year, p->month, p->day );

	}
	break;


	case WM_MOUSEWHEEL :

		if ( n_win_is_hovered( p->hgui ) )
		{

			int delta = n_win_scroll_wheeldelta( wparam, 1 );

			if ( delta == 0 ) { break; }

			p->month += delta;
			if ( p->month <  1 ) { p->year--; p->month = 12; } else
			if ( p->month > 12 ) { p->year++; p->month =  1; }


			n_win_refresh( p->hgui, false );

		}

	break;

	case WM_KEYDOWN :

		if ( n_win_is_hovered( p->hgui ) )
		{

			if ( wparam == VK_UP )
			{
				p->year = n_posix_max( 1900, p->year - 1 );
			} else
			if ( wparam == VK_DOWN )
			{
				p->year = n_posix_min( 9999, p->year + 1 );
			} else
			if ( wparam == VK_LEFT )
			{
				p->month--; if ( p->month <  1 ) { p->year--; p->month = 12; }
			} else
			if ( wparam == VK_RIGHT )
			{
				p->month++; if ( p->month > 12 ) { p->year++; p->month =  1; }
			} else
			//
			{
				break;
			}

			n_win_refresh( p->hgui, false );

		}

	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_CALENDAR


/*


#include "./win.c"


#include "../project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static n_win_calendar h_calendar[ 2 ];


	switch( msg ) {


	case WM_CREATE :

		// Global

		n_project_darkmode()
		//n_win_darkmode_onoff = true;


		// Window

		n_win_init_literal( hwnd, "Nonnon Calendar Test", "", "" );


		n_win_calendar_init( &h_calendar[ 0 ], hwnd );
		n_win_calendar_init( &h_calendar[ 1 ], hwnd );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		// Size

		n_win_set( hwnd, NULL, 256*2,256, N_WIN_SET_CENTERING );
		WndProc( hwnd, WM_SIZE, 0,0 );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_SIZE :
	{

		n_win w; n_win_set( hwnd, &w, -1,-1, N_WIN_SET_DEFAULT );

		s32 sx = w.csx / 2;
		s32 sy = w.csy;

		n_win_move( h_calendar[ 0 ].hgui,  0,0, sx,sy, true );
		n_win_move( h_calendar[ 1 ].hgui, sx,0, sx,sy, true );

	}
	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_calendar_exit( &h_calendar[ 0 ], hwnd );
		n_win_calendar_exit( &h_calendar[ 1 ], hwnd );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_calendar_proc( hwnd,msg,wparam,lparam, &h_calendar[ 0 ] );
	n_win_calendar_proc( hwnd,msg,wparam,lparam, &h_calendar[ 1 ] );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}


*/


