// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include <string.h>

#include <windows.h>
#include <richedit.h>




extern n_txt txt;


static unsigned long *n_viewer_line;

static char    n_viewer_fontsize;

static HMODULE n_viewer_hmodule = NULL;
static WNDPROC n_viewer_pfunc;




#define N_VIEWER_REFRESH(hwnd) SendMessage(hwnd, WM_NULL, 0,0)

// internal
void
n_viewer_line_init(void)
{

	unsigned long i, line;


	n_viewer_line = realloc(n_viewer_line, 0);
	n_viewer_line = realloc(n_viewer_line, sizeof(long) * txt.sy );

	ZeroMemory( n_viewer_line, sizeof(long) * txt.sy );


	n_viewer_line[ 0 ] = 0;

	line = 1;

	i = 0;
	while( 1 )
	{

		// PATCH : Win9x
		//	for some buggy text files like "setuplog.txt"
		//	includes CRLFs and LFs


		if ( txt.ptr[i] == 0x0A )
		{

			txt.ptr[i] = 0x0D;


			i++;
			if ( i >= txt.size ) { break; }


			n_viewer_line[ line ] = i;

			line++;
			if ( line >= txt.sy ) { break; }

		} else
		if ( txt.ptr[i] == 0x0D )
		{

			i++;
			if ( i >= txt.size ) { break; }


			if (
				( i <= ( txt.size - 1 ) )
				&&
				( txt.ptr[i] == 0x0A )
			)
			{
				i++;
				if ( i >= txt.size ) { break; }

			}

			n_viewer_line[ line ] = i;

			line++;
			if ( line >= txt.sy ) { break; }

		} else {

			i++;
			if ( i >= txt.size ) { break; }
		}

	}

	if ( txt.sy != line )
	{
		// inaccessible : i == txt.size

		n_viewer_line[ line ] = i;

		line++;
	}

/*
{ // DEBUG BEGIN

char str[100];

sprintf(str, "%d : %d - %d", (int) txt.sx, (int) txt.sy, (int) line);

MessageBox(NULL, str, "DEBUG", 0);

} // DEBUG END
*/

	return;
}

// internal
unsigned long
n_viewer_line_get(unsigned long line, char *ret)
{

	unsigned long i, offset;


	if ( txt.sy <= line ) { return 0; }

//return 0;


	offset = n_viewer_line[ line ];

	if ( offset >= txt.size ) { return 0; }


	i = 0;
	while( 1 )
	{
		if ( txt.ptr[ offset + i ] == 0x0D ) { break; }

		if ( ret != NULL )
		{
			ret[i] = txt.ptr[ offset + i ];
		}


		i++;
		if ( txt.ptr[ offset + i ] == 0    ) { break; }
	}

	if ( ret != NULL )
	{
		ret[i] = 0;
	}


	return i;
}

// internal
void
n_viewer_draw(HWND hwnd, int x, int y, int maxline)
{

	char *buffer, *line;

	unsigned long i,ii, len;


	SetWindowText(hwnd, "");


	len = txt.sx * txt.sy;

	buffer = calloc( len    + 1, sizeof(char) );
	line   = calloc( txt.sx + 1, sizeof(char) );

	i  = y;
	ii = 0;
	while( 1 )
	{
		n_viewer_line_get(i, line);

		if ( x < strlen(line) )
		{
			sprintf(&buffer[ii], "%s", &line[x]);

			ii += strlen(&line[x]);
			if ( ii >= len ) { break; }
		}

		buffer[ii] = 0x0D; ii++;
		buffer[ii] = 0x0A; ii++;


		i++;
		if ( i >= ( txt.sy - 1 ) ) { break; }
	}

	SetWindowText(hwnd, buffer);

	free(buffer);
	free(line);


	return;
}

// internal
LRESULT CALLBACK
n_viewer_subclass(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
char str[1024];


	MSG struct_msg;

	SCROLLINFO si;
	int        scroll;

	int        step;
	RECT       rect;


	scroll = -1;


	switch(msg) {

	case WM_VSCROLL :

		scroll = SB_VERT;

	break;
	case WM_HSCROLL :

		scroll = SB_HORZ;

	break;

	case WM_MOUSEWHEEL :

//sprintf(str, "%d", (int) wparam);
//MessageBox(hwnd, str, "DEBUG", 0);


		// Win98   : doesn't wheel-scroll automatically
		// Win2000 : prevent smooth scroll


		if ( (int) wparam > 0 )
		{
			scroll = SB_VERT;

			msg        = WM_VSCROLL;
			wparam     = SB_LINEUP;
			lparam     = 0;

		} else
		if ( (int) wparam < 0 )
		{
			scroll = SB_VERT;

			msg        = WM_VSCROLL;
			wparam     = SB_LINEDOWN;
			lparam     = 0;
		}

	break;

/*
	case EM_LINESCROLL :

		// Win2000 : if processing, fail to free hmodule

		scroll = SB_VERT;

		msg        = WM_VSCROLL;
		wparam     = MAKEWPARAM(SB_THUMBTRACK, lparam);
		lparam     = 0;

	break;
*/
/*
	case WM_LBUTTONDBLCLK :

		// using WS_*SCROLL and SB_THUMBTRACK
		//
		// Win98 : over-scrolling at the last column

		PeekMessage(&struct_msg, NULL,0,0,PM_REMOVE);

		return 0;

	break;
*/
	case WM_NULL :

		n_viewer_line_init();

		SetWindowText(hwnd, "");

		SendMessage(hwnd, EM_SETLIMITTEXT, 0, (LPARAM) txt.size);

		SetWindowText(hwnd, txt.ptr);

		SendMessage(hwnd, WM_VSCROLL, SB_ENDSCROLL, 0);
		SendMessage(hwnd, WM_HSCROLL, SB_ENDSCROLL, 0);

	break;

/*
	case WM_GETTEXT :
	case WM_SETTEXT :

		// never come

	break;


	default :

		if (msg>=WM_USER)
		{
			sprintf(str, "%d", msg);
			SetWindowText( GetParent(hwnd), str);
		}
*/

	} // switch


	if ( scroll != -1 )
	{
		// Win2000 : heavy
		// Win9x   : doesn't function

		// using WS_*SCROLL and SB_THUMBTRACK
		//
		// over-scrolling when pressing down/right arrow
		//
		// Win9x   : VERT and HORZ
		// Win2000 : HORZ only, but VERT is incorrect
		//
		// cannot know the needed nMax size
		//
		//	.nMax           : has previous value
		//	EM_GETLINECOUNT : returns invalid value
		//
		//	nMax is not "EM_GETLINECOUNT * step"

		// cannot know the line height
		//
		//	Win2000 : vertical spacing
		//	16pt =>  4px
		//	35pt => 10px


//sprintf(str, "%d", (int)SendMessage(hwnd, EM_GETLINECOUNT, 0,0) );
//SetWindowText( GetParent(hwnd), str);


		//step = n_riched_fontsize;
		step = 1;


		ZeroMemory( &si, sizeof(SCROLLINFO) );

		si.cbSize = sizeof(SCROLLINFO);
		si.fMask  = SIF_ALL;

		GetScrollInfo(hwnd, scroll, &si);


		si.nMin = 0;

		GetClientRect(hwnd, &rect);
		if ( scroll == SB_VERT )
		{
			//si.nMax  = txt.sy * n_riched_fontsize;
			//si.nPage = rect.bottom;

			si.nMax  = txt.sy;
			si.nPage = rect.bottom / n_viewer_fontsize;
		} else {
			//si.nMax  = txt.sx * ( n_riched_fontsize/2 );
			//si.nPage = rect.right;

			si.nMax  = txt.sx;
			si.nPage = rect.right / n_viewer_fontsize * 2;
		}

sprintf(str, "%d %d", (int)txt.sy, (int)txt.sx);

//sprintf(str, "%d %d", si.nMax, si.nPage);
SetWindowText( GetParent(hwnd), str);


		if ( si.nMax < si.nPage ) { step = 0; }


		switch( LOWORD(wparam) ) {

		case SB_LINEUP :

			si.nPos -= step;

		break;
		case SB_LINEDOWN :

			si.nPos += step;

		break;

		case SB_PAGEUP :

			si.nPos -= si.nPage;

		break;
		case SB_PAGEDOWN :

			si.nPos += si.nPage;

		break;

		case SB_TOP :

			si.nPos = si.nMin;

		break;
		case SB_BOTTOM :

			si.nPos = si.nMax;

		break;

		case SB_THUMBPOSITION :
		case SB_THUMBTRACK    :

			// using WS_*SCROLL and SB_THUMBTRACK
			//
			// Win98 : SB_THUMBPOSITION
			// 	mis-behave when a cursor in bottom-right 32x32

			si.nPos = HIWORD(wparam);

		break;

		} // switch


		if ( si.nPos < 0 )
		{
			si.nPos = 0;
		}
		if ( si.nPos >= ( si.nMax - si.nPage + 1 ) )
		{
			si.nPos = si.nMax - si.nPage + 1;
		}

//sprintf(str, "%d %d", si.nMax - si.nPage, si.nPos);
//SetWindowText( GetParent(hwnd), str);

		// using WS_*SCROLL and SB_THUMBTRACK
		//
		// PROBLEM : EM_SETSCROLLPOS : rich edit 3.0 or later
		//
		// Win2000 : cannot fix
		//	buggy behavior when VSCROLL at bottom
		//	force to put a first visible line on y=0

/*
		if ( scroll==SB_VERT )
		{
			msg = WM_VSCROLL;
		} else
		if ( scroll==SB_HORZ )
		{
			msg = WM_HSCROLL;
		}
		wparam = MAKEWPARAM(SB_THUMBTRACK, si.nPos);
		CallWindowProc(n_riched_pfunc, hwnd, msg, wparam, 0);
*/

		if ( n_viewer_line != NULL )
		{
			SCROLLINFO si_another;


			ZeroMemory( &si_another, sizeof(SCROLLINFO) );

			si_another.cbSize = sizeof(SCROLLINFO);
			si_another.fMask  = SIF_ALL;


			if ( scroll == SB_VERT )
			{

				GetScrollInfo(hwnd, SB_HORZ, &si_another);

				n_viewer_draw(hwnd, si_another.nPos, si.nPos, si.nPage);

				//unsigned long pos;

				//pos = n_viewer_line[si.nPos];

				//SetWindowText(hwnd, &txt.ptr[pos]);
			} else {

				GetScrollInfo(hwnd, SB_VERT, &si_another);

				n_viewer_draw(hwnd, si.nPos, si_another.nPos, si.nPage);

			}

			SetScrollInfo(hwnd, scroll, &si, true);
		}


		PeekMessage(&struct_msg, NULL,0,0,PM_REMOVE);


		return 0;

	}


	return CallWindowProc(n_viewer_pfunc, hwnd, msg, wparam, lparam);
}

void
n_viewer_load(HWND hwnd, HWND *hwnd_ctl)
{

	if ( hwnd == NULL ) { return; }


	n_viewer_hmodule = LoadLibrary("riched32.dll");

	(*hwnd_ctl) = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		"RICHEDIT",
		"",
		WS_CHILD       | WS_VISIBLE    |
		//WS_VSCROLL     | WS_HSCROLL    |
		ES_MULTILINE   | ES_WANTRETURN |
		ES_READONLY    |
		ES_NOHIDESEL,
		0,0, 0,0,
		hwnd,
		(HMENU) NULL,
		GetModuleHandle(NULL),
		NULL 
	);
//if ( (*hwnd_ctl) == NULL ) { MessageBox(NULL, "RichEdit : Load", "DEBUG", 0); }


	n_viewer_pfunc = n_win_gui_subclass_set( (*hwnd_ctl), n_viewer_subclass);


	return;
}

void
n_viewer_font(HWND hwnd_ctl, HFONT hfont)
{

	// vertical spacing
	//
	//	Win2000 : by unknown calculation (maybe twips & float)
	//	Win95   : default is zero


	HWND hwnd = GetParent(hwnd_ctl);

	int i;

	int tmp;

	CHARFORMAT cf;
	PARAFORMAT pf;

	HDC   hdc;

	HFONT hfont_old;
	SIZE  size;


	hdc = GetDC(hwnd);


	hfont_old = SelectObject(hdc, hfont);

	GetTextExtentPoint32(hdc, "a", strlen("a"), &size);

	SelectObject(hdc, hfont_old);


	tmp = 1440 / GetDeviceCaps(hdc, LOGPIXELSY);


	ReleaseDC(hwnd, hdc);


	n_viewer_fontsize = size.cy + 4;


	ZeroMemory( &cf, sizeof(CHARFORMAT) );
	cf.cbSize          = sizeof(CHARFORMAT);
	cf.dwMask          = CFM_EFFECTS | CFM_COLOR | CFM_SIZE | CFM_FACE | CFM_CHARSET;
	cf.dwEffects       = CFE_AUTOCOLOR;
	cf.yHeight         = n_viewer_fontsize * tmp;
	cf.yOffset         = 0;
	cf.bCharSet        = DEFAULT_CHARSET;
	cf.bPitchAndFamily = FIXED_PITCH | FF_SWISS;
	SendMessage(hwnd_ctl, EM_SETCHARFORMAT, (WPARAM) SCF_ALL, (LPARAM) &cf);


	ZeroMemory( &pf, sizeof(PARAFORMAT) );
	pf.cbSize          = sizeof(PARAFORMAT);
	pf.dwMask          = PFM_STARTINDENT | PFM_TABSTOPS;
	pf.dxStartIndent   = 4 * tmp;
	pf.cTabCount       = MAX_TAB_STOPS;

	// width * char_count
	tmp = ( (n_viewer_fontsize * tmp) / 2 ) * 8;

	i = 0;
	while( 1 )
	{
		pf.rgxTabs[i] = tmp * (i+1);

		i++;
		if ( i >= MAX_TAB_STOPS ) { break; }
	}
	SendMessage(hwnd_ctl, EM_SETPARAFORMAT, 0, (LPARAM) &pf);


	SendMessage( hwnd_ctl, WM_SETFONT, (WPARAM) hfont, false );


	return;
}

void
n_viewer_free(void)
{
	// after DestroyWindow()

	free(n_viewer_line);

	FreeLibrary(n_viewer_hmodule);

	return;
}

